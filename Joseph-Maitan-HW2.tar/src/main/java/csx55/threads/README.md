Example of how to run threads code: 

java -cp build/classes/java/main/ csx55.threads.MatrixThreads 8 3000 31459